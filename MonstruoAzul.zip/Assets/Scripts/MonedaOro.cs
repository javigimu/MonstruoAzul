using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonedaOro : MonoBehaviour
{
    private AudioSource sonidoRecogerItem;

    // Start is called before the first frame update
    void Start()
    {
        sonidoRecogerItem = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D otro)
    {
        if (otro.tag == "Player")
        {
            EscucharSonidoSalto();
            FindObjectOfType<GameController>().SendMessage(
                "AnotarItemRecogido", 10);
            Destroy(gameObject);
        }
    }

    private void EscucharSonidoSalto()
    {
        AudioSource.PlayClipAtPoint(sonidoRecogerItem.clip,
            Camera.main.transform.position);
    }
}
