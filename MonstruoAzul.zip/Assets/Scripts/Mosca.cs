using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Mosca : MonoBehaviour
{
    private float velocidad;
    [SerializeField] List<Transform> wayPoints;
    private Vector3 siguientePosicion;
    private int numeroSiguientePosicion = 0;
    private float distanciaCambio = 0.2f;

    // Start is called before the first frame update
    void Start()
    {
        siguientePosicion = wayPoints[0].position;
        velocidad = FindObjectOfType<GameStatus>().velocidadMoscas;
    }

    // Update is called once per frame
    void Update()
    {
        MoverHaciaWaypoints();
    }

    private void OnTriggerEnter2D(Collider2D otro)
    {
        if (otro.tag == "Player")
        {
            FindObjectOfType<GameController>().SendMessage("PerderVida");
        }
    }

    private void MoverHaciaWaypoints()
    {
        transform.position = Vector3.MoveTowards(
            transform.position, siguientePosicion, velocidad * Time.deltaTime);

        if (Vector3.Distance(
            transform.position, siguientePosicion) < distanciaCambio)
        {
            numeroSiguientePosicion++;
            if (numeroSiguientePosicion >= wayPoints.Count)
                numeroSiguientePosicion = 0;

            siguientePosicion = wayPoints[numeroSiguientePosicion].position;
        }
    }
}
