using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.ConstrainedExecution;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

// Clase para controlar las funcionalidades b�sicas del juego, asociado a la 
// clase GameStatus utilizando el patr�n Singleton
/// <summary>
/// Para avanzar de nivel hay que recoger todas las monedas y es entonces
/// cuando aparece una llave que hay que recoger para pasar de nivel
/// </summary>

public class GameController : MonoBehaviour
{   
    private int puntos;
    private int vidas;
    [SerializeField] TextMeshProUGUI textoMarcador;
    private int itemsRestantes;
    private int nivelActual;
    private int nivelMaximo;
    [SerializeField] Transform key;
    [SerializeField] TMP_Text textoGameOver;
    private const string MENSAJE_FIN = "Fin\n\nPuntos obtenidos: ";
    private const string MENSAJE_GAMEOVER = "Game Over";

    // Start is called before the first frame update
    void Start()
    {
        textoGameOver.enabled = false;
        puntos = FindObjectOfType<GameStatus>().puntos;
        vidas = FindObjectOfType<GameStatus>().vidas;
        itemsRestantes = FindObjectsOfType<MonedaOro>().Length;
        nivelActual = FindObjectOfType<GameStatus>().nivelActual;
        nivelMaximo = FindObjectOfType<GameStatus>().nivelMaximo;
        key.gameObject.SetActive(false);
        ActualizarMarcador();
    }

    // Update is called once per frame
    void Update()
    {
        AvanzarNivelConTabulador();
        ControlarFinDeJuego();
        // Al pulsar esc se sale al menu de bienvenida
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TerminarPartida("");
        }    
    }

    private void ControlarFinDeJuego()
    {
        if (nivelActual >= nivelMaximo)
        {
            if (itemsRestantes <= 0)
                TerminarPartida(MENSAJE_FIN + puntos);
        }
    }

    // M�todo para avanzar nivel utilizado en las pruebas
    private void AvanzarNivelConTabulador()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
            AvanzarNivel();
    }

    private void AnotarItemRecogido(int puntosObtenidos)
    {
        puntos += puntosObtenidos;
        FindObjectOfType<GameStatus>().puntos = puntos;
        itemsRestantes--;
        ActualizarMarcador();

        if (itemsRestantes <= 0)
            MostrarKey();
    }

    private void MostrarKey()
    {
        key.gameObject.SetActive(true);
    }

    private void AvanzarNivel()
    {
        nivelActual++;
        if (nivelActual > nivelMaximo)
        { 
            TerminarPartida(MENSAJE_FIN + puntos);
        }
        else
        {
            // aumenta la velocidad de las moscas seg�n el nivelActual
            FindObjectOfType<GameStatus>().velocidadMoscas += 0.5f;

            FindObjectOfType<GameStatus>().nivelActual = nivelActual;
            SceneManager.LoadScene("Nivel" + nivelActual);
        }
    }

    private void ActualizarMarcador()
    {
        textoMarcador.text = "Puntos: " + puntos + "\nVidas: " + vidas
            +"\nItems Restantes: " + itemsRestantes;
    }

    private void PerderVida()
    {
        vidas--;
        FindObjectOfType<GameStatus>().vidas = vidas;
        
        if (vidas <= 0)
        {
            TerminarPartida(MENSAJE_GAMEOVER);
        }
        ActualizarMarcador();        
        FindObjectOfType<Player>().SendMessage("Recolocar");
    }

    private void TerminarPartida(string mensaje)
    {
        StartCoroutine(VolverAlMenuPrincipal(mensaje));
    }

    private IEnumerator VolverAlMenuPrincipal(string mensaje)
    {
        // Ralentizo el juego, espero 3 segundos y lanzo la bienvenida

        textoGameOver.color = Color.gray;
        textoGameOver.text = mensaje;
        textoGameOver.enabled = true;
        ReiniciarMarcador();
        Time.timeScale = 0.1f;
        yield return new WaitForSecondsRealtime(3);
        Time.timeScale = 1;
        SceneManager.LoadScene("Bienvenida");
    }

    private void ReiniciarMarcador()
    {
        FindObjectOfType<GameStatus>().vidas = 3;
        FindObjectOfType<GameStatus>().puntos = 0;
        FindObjectOfType<GameStatus>().nivelActual = 1;
        FindObjectOfType<GameStatus>().velocidadMoscas =
            FindObjectOfType<GameStatus>().velocidadMoscasInicial;

    }
}
