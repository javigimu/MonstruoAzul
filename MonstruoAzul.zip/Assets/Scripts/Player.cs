using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private float velocidad = 4;
    private float xInicial, yInicial;
    [SerializeField] float velocidadSalto = 5; // velocidad para correcto funcionamiento tras generar ejecutable
    private float alturaPlayer;
    private Animator animator;
    private AudioSource sonidoSalto;

    // Start is called before the first frame update
    void Start()
    {
        xInicial = transform.position.x;
        yInicial = transform.position.y;
        alturaPlayer = GetComponent<Collider2D>().bounds.size.y;
        animator = gameObject.GetComponent<Animator>();
        sonidoSalto = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        MoverPlayer();
    }

    private void AnimarPersonajeCorriendo(float horizontal)
    {
        if ((horizontal > 0.1f) || (horizontal < -0.1f))
        {
            animator.Play("PersonajeCorriendo");
        }
    }

    private void AnimarPersonajeSaltando()
    {
        animator.Play("PersonajeSaltando");
    }

    private void MoverPlayer()
    {
        float horiontal = Input.GetAxis("Horizontal");
        AnimarPersonajeCorriendo(horiontal);

        transform.Translate(horiontal * velocidad * Time.deltaTime, 0, 0);

        float salto = Input.GetAxis("Jump");
        if (salto > 0)
        {                        
            Saltar(salto);
        }        
    }

    private void Saltar(float salto)
    {
        RaycastHit2D hit =
            Physics2D.Raycast(transform.position, new Vector2(0, -1));

        if (hit.collider != null)
        {
            float distanciaAlSuelo = hit.distance;
            bool tocandoElSuelo = distanciaAlSuelo < alturaPlayer;
            if (tocandoElSuelo)
            {
                AnimarPersonajeSaltando();
                EscucharSonidoSalto();
                Vector3 fuerzaSalto = new Vector3(0, velocidadSalto, 0);
                GetComponent<Rigidbody2D>().AddForce(fuerzaSalto);
            }
        }
    }

    private void EscucharSonidoSalto()
    {
        AudioSource.PlayClipAtPoint(sonidoSalto.clip, transform.position);
    }

    private void Recolocar()
    {
        transform.position = new Vector3(xInicial, yInicial, 0);
    }

    private void RecolocarEnTopeSuperior(float yTopeSuperior)
    {
        transform.position = new Vector3(transform.position.x,yTopeSuperior, 0);
    }
}
